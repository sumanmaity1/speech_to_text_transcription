-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3325
-- Generation Time: Jan 21, 2021 at 09:57 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `speech`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `userName` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`userName`, `pass`) VALUES
('suman', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `t1`
--

CREATE TABLE `t1` (
  `id` int(11) NOT NULL,
  `speech_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `speech` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t1`
--

INSERT INTO `t1` (`id`, `speech_time`, `speech`) VALUES
(5, '2021-01-21 06:04:27', 'hello'),
(6, '2021-01-21 06:04:27', 'hello hi how are you'),
(7, '2021-01-21 06:04:27', 'hello hi'),
(8, '2021-01-21 06:05:46', 'how are you hello hello again'),
(9, '2021-01-21 06:06:31', ' super super'),
(10, '2021-01-21 06:35:25', 'hello hi'),
(11, '2021-01-21 06:38:33', 'Suman'),
(12, '2021-01-21 06:55:21', 'hello  welcome to our page'),
(13, '2021-01-21 06:55:53', 'hello  welcome to our page'),
(14, '2021-01-21 06:55:56', 'hello  welcome to our page'),
(15, '2021-01-21 08:45:56', 'hello'),
(16, '2021-01-21 08:48:42', 'hello there');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `t1`
--
ALTER TABLE `t1`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `t1`
--
ALTER TABLE `t1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
